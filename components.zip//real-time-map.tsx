import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { 
  MapPin, 
  Navigation, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  RefreshCw,
  Zap
} from 'lucide-react';

interface TrafficLight {
  id: string;
  name: string;
  x: number;
  y: number;
  status: 'normal' | 'warning' | 'critical';
  flow: number;
  waitTime: number;
  lastUpdate: Date;
}

export function RealTimeMap() {
  const [trafficLights, setTrafficLights] = useState<TrafficLight[]>([]);
  const [selectedLight, setSelectedLight] = useState<TrafficLight | null>(null);
  const [isAutoRefresh, setIsAutoRefresh] = useState(true);

  useEffect(() => {
    generateTrafficLights();
    
    let interval: NodeJS.Timeout;
    if (isAutoRefresh) {
      interval = setInterval(() => {
        updateTrafficLights();
      }, 3000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isAutoRefresh]);

  const generateTrafficLights = () => {
    const lights: TrafficLight[] = [
      { id: '1', name: 'Main St & 1st Ave', x: 20, y: 30, status: 'normal', flow: 245, waitTime: 45, lastUpdate: new Date() },
      { id: '2', name: 'Broadway & 2nd St', x: 35, y: 25, status: 'warning', flow: 189, waitTime: 78, lastUpdate: new Date() },
      { id: '3', name: 'Oak Ave & 3rd St', x: 50, y: 40, status: 'critical', flow: 312, waitTime: 156, lastUpdate: new Date() },
      { id: '4', name: 'Pine St & 4th Ave', x: 65, y: 35, status: 'normal', flow: 198, waitTime: 32, lastUpdate: new Date() },
      { id: '5', name: 'Elm St & 5th Ave', x: 80, y: 45, status: 'normal', flow: 223, waitTime: 41, lastUpdate: new Date() },
      { id: '6', name: 'Cedar Ave & 6th St', x: 30, y: 60, status: 'warning', flow: 267, waitTime: 89, lastUpdate: new Date() },
      { id: '7', name: 'Maple St & 7th Ave', x: 45, y: 70, status: 'normal', flow: 145, waitTime: 28, lastUpdate: new Date() },
      { id: '8', name: 'Birch Ave & 8th St', x: 70, y: 65, status: 'normal', flow: 201, waitTime: 38, lastUpdate: new Date() },
    ];
    setTrafficLights(lights);
  };

  const updateTrafficLights = () => {
    setTrafficLights(prev => prev.map(light => ({
      ...light,
      flow: Math.max(50, light.flow + (Math.random() - 0.5) * 40),
      waitTime: Math.max(15, light.waitTime + (Math.random() - 0.5) * 20),
      status: light.waitTime > 100 ? 'critical' : light.waitTime > 60 ? 'warning' : 'normal',
      lastUpdate: new Date()
    })));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'bg-red-500';
      case 'warning': return 'bg-yellow-500';
      default: return 'bg-green-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'critical': return AlertTriangle;
      case 'warning': return Clock;
      default: return CheckCircle;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Live Traffic Map</h3>
          <p className="text-sm text-gray-600">Real-time intersection monitoring</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant={isAutoRefresh ? "default" : "outline"}
            size="sm"
            onClick={() => setIsAutoRefresh(!isAutoRefresh)}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isAutoRefresh ? 'animate-spin' : ''}`} />
            Auto Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Visualization */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Navigation className="h-5 w-5" />
              <span>City Traffic Grid</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative bg-gray-100 rounded-lg h-96 overflow-hidden">
              {/* Street Grid Background */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100">
                {/* Horizontal Streets */}
                {[20, 35, 50, 65, 80].map(y => (
                  <line key={`h-${y}`} x1="0" y1={y} x2="100" y2={y} stroke="#CBD5E1" strokeWidth="0.5" />
                ))}
                {/* Vertical Streets */}
                {[15, 30, 45, 60, 75].map(x => (
                  <line key={`v-${x}`} x1={x} y1="0" x2={x} y2="100" stroke="#CBD5E1" strokeWidth="0.5" />
                ))}
              </svg>

              {/* Traffic Lights */}
              {trafficLights.map(light => {
                const StatusIcon = getStatusIcon(light.status);
                return (
                  <div
                    key={light.id}
                    className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 hover:scale-110 ${
                      selectedLight?.id === light.id ? 'ring-4 ring-blue-300 rounded-full' : ''
                    }`}
                    style={{ left: `${light.x}%`, top: `${light.y}%` }}
                    onClick={() => setSelectedLight(light)}
                  >
                    <div className={`w-4 h-4 rounded-full ${getStatusColor(light.status)} shadow-lg flex items-center justify-center`}>
                      <StatusIcon className="h-2 w-2 text-white" />
                    </div>
                    {selectedLight?.id === light.id && (
                      <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-white p-2 rounded shadow-lg border text-xs whitespace-nowrap z-10">
                        <p className="font-medium">{light.name}</p>
                        <p>Flow: {Math.round(light.flow)} veh/hr</p>
                        <p>Wait: {Math.round(light.waitTime)}s</p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="flex items-center justify-center space-x-6 mt-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span>Normal</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                <span>Warning</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <span>Critical</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Intersection Details */}
        <Card>
          <CardHeader>
            <CardTitle>Intersection Details</CardTitle>
            <CardDescription>
              {selectedLight ? 'Selected intersection info' : 'Click on a traffic light to view details'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedLight ? (
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium">{selectedLight.name}</h4>
                  <Badge variant={selectedLight.status === 'critical' ? 'destructive' : selectedLight.status === 'warning' ? 'secondary' : 'default'}>
                    {selectedLight.status.toUpperCase()}
                  </Badge>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Traffic Flow:</span>
                    <span className="font-medium">{Math.round(selectedLight.flow)} veh/hr</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Avg Wait Time:</span>
                    <span className="font-medium">{Math.round(selectedLight.waitTime)}s</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Last Update:</span>
                    <span className="text-sm">{selectedLight.lastUpdate.toLocaleTimeString()}</span>
                  </div>

                  <div className="pt-2 border-t">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-600">Efficiency:</span>
                      <span className={`font-medium ${
                        selectedLight.waitTime < 45 ? 'text-green-600' : 
                        selectedLight.waitTime < 80 ? 'text-yellow-600' : 'text-red-600'
                      }`}>
                        {selectedLight.waitTime < 45 ? 'High' : selectedLight.waitTime < 80 ? 'Medium' : 'Low'}
                      </span>
                    </div>
                    
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          selectedLight.waitTime < 45 ? 'bg-green-500' : 
                          selectedLight.waitTime < 80 ? 'bg-yellow-500' : 'bg-red-500'
                        }`}
                        style={{ width: `${Math.max(20, 100 - selectedLight.waitTime)}%` }}
                      ></div>
                    </div>
                  </div>
                </div>

                <Button className="w-full" size="sm">
                  <Zap className="h-4 w-4 mr-2" />
                  Optimize Timing
                </Button>
              </div>
            ) : (
              <div className="text-center text-gray-500 py-8">
                <MapPin className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Select an intersection on the map to view detailed information</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}